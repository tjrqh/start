package member.Presentation;

import member.application.MemberApplication;
import member.application.MemberDto;
import member.domain.entity.Member;

public class MemberCLIInterface {
    private MemberApplication memberApplication;

    public MemberCLIInterface(MemberApplication memberApplication) {
        this.memberApplication = memberApplication;
    }

    public boolean signUp(String id, String password, String name, String email){
        return this.memberApplication.signUp(new MemberDto(id, password, name, email));
    }

}
