package member.application;

import member.domain.entity.Member;
import member.domain.repository.MemberRepository;
import member.domain.session.MemberSession;

import java.util.ArrayList;

public class MemberApplication {
    private ArrayList<Member> memberList;
    private MemberRepository memberRepository;
    private MemberSession memberSession;


    public MemberApplication(MemberSession memberSession) {
        this.memberSession = memberSession;
    }

    public MemberApplication(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }


    public boolean signUp(MemberDto memberDto){
        if(memberDto.getId() != null) { // getId가 있으면 false 로 return
            return false;
        }
        return this.memberRepository.create(new Member(memberDto.getId(), memberDto.getPassword(),memberDto.getName(),memberDto.getEmail()));
    }

    public boolean signIn(String id, String password){
        for(int i =0; i<memberList.size(); i++) {
            if(memberList.get(i).getId().equals(id) == false){
                continue;
                }
            else if(memberList.get(i).getId().equals(id) == true) {
                if(memberList.get(i).getId().equals(password) == false) {
                    continue;
                }
            }
         }

        return true;
    }

    public boolean logOut(String id){
        if(id == null){
            return false;
        }
        return true;
    }

    public boolean read(String id){
        if(memberList.isEmpty()){
            System.out.println("정보가 없습니다");
        }
        else{
            for(int i = 0; i < memberList.size(); i++) {
                if(memberList.get(i).getId().equals(id)==false){
                    continue;
                }
            }
        }
        return read(id);
    }

    public boolean update(Member name){
        for(int i = 0; i < memberList.size(); i++) {
            if (memberList.get(i).equals(name) == false) {
                continue;
            }
        }
        return this.memberRepository.update(name);
    }

    public boolean exit(String id){
        return false;
    }

}
